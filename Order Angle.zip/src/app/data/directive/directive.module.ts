import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClickOutsideDirective } from './clickOutSide.directive';
import { SwiperDirective } from './swiper.directive';
import { ScrollCenterDirective } from './scrollCenter.directive';


@NgModule({
    declarations: [ClickOutsideDirective , SwiperDirective , ScrollCenterDirective],
    imports: [
        CommonModule
    ],
    exports: [ ClickOutsideDirective , SwiperDirective , ScrollCenterDirective]
})
export class DirectivesModule { }
