import { Component } from '@angular/core';

@Component({
  selector: 'app-web-ordering',
  templateUrl: './web-ordering.component.html',
  styleUrls: ['./web-ordering.component.scss']
})
export class WebOrderingComponent {

}
