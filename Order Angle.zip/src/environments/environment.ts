export const environment = {
  API_URL: 'https://stagingapi.deliveryangel.com',
  // API_URL: 'https://api.deliveryangel.com',
  // API_URL: 'https://quickly-bright-lionfish.ngrok-free.app',
  // IMAGE_URL: 'https://api.deliveryangel.com/',
  IMAGE_URL: 'https://stagingapi.deliveryangel.com/',
  // MASS_NOTIFICATION_API_URL: 'http://192.168.0.180:3000',
  BASE_URL: 'https://sweet-awfully-tomcat.ngrok-free.app',
  SOCKET_URL: 'https://sweet-awfully-tomcat.ngrok-free.app/',

  // STRIPE_KEY:'pk_live_51IaXPZIUvxJzsGa7wE85QwmzlHbpyrEXo3dG8Puj8IAaNOBCPbuJjjdxR5eYNP2GzC1nq0oKjCRLGHv1aOsQ68On00naTU8BuS'
  STRIPE_KEY:'pk_test_51IaXPZIUvxJzsGa77vgr8DTGNKqerXppKEzUX7a7J6Hii4Uvjh3EwIhpZgdI59B5Relxqx99lpkquR1jwaBY9xJY00nMNpNHFE'
//   COUNTRY_API : 'https://restcountries.com/v3.1/alpha?codes=170,no,est,pe'
};
